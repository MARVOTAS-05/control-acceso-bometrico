INSERT INTO areas (nombre_area) VALUES
 ('Administración'),('Recursos Humanos'),('Contabilidad'),
 ('Operaciones'),('Mantenimiento'),('Sistemas');

INSERT INTO roles (nombre_rol, descripcion) VALUES
 ('ADMIN_SISTEMAS','Administra la plataforma'),
 ('RRHH','Consulta asistencia y gestiona personas'),
 ('AUDITOR','Solo lectura y auditoría'),
 ('EMPLEADO','Consulta su propia asistencia');

INSERT INTO personas (nombre, apellido, documento, id_area)
WITH RECURSIVE seq AS (
  SELECT 1 AS n UNION ALL SELECT n + 1 FROM seq WHERE n < 200
)
SELECT CONCAT('Persona ', n), 'Prueba', CONCAT('DOC', n), 1 + (n % 6) FROM seq;
