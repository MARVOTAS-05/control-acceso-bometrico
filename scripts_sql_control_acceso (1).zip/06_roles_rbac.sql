CREATE ROLE 'rol_admin_sistemas', 'rol_rrhh', 'rol_auditor',
            'rol_servicio_biometrico', 'rol_empleado';

GRANT SELECT, INSERT, UPDATE, DELETE ON control_acceso.areas     TO 'rol_admin_sistemas';
GRANT SELECT, INSERT, UPDATE, DELETE ON control_acceso.personas  TO 'rol_admin_sistemas';
GRANT SELECT, INSERT, UPDATE, DELETE ON control_acceso.roles     TO 'rol_admin_sistemas';
GRANT SELECT, INSERT, UPDATE, DELETE ON control_acceso.usuarios  TO 'rol_admin_sistemas';
GRANT INSERT, UPDATE, DELETE ON control_acceso.rostros           TO 'rol_admin_sistemas';
GRANT INSERT, UPDATE, DELETE ON control_acceso.huellas           TO 'rol_admin_sistemas';
GRANT SELECT ON control_acceso.accesos                           TO 'rol_admin_sistemas';
GRANT SELECT ON control_acceso.auditoria                         TO 'rol_admin_sistemas';

GRANT SELECT ON control_acceso.areas   TO 'rol_rrhh';
GRANT SELECT ON control_acceso.accesos TO 'rol_rrhh';
GRANT SELECT, INSERT, UPDATE ON control_acceso.personas TO 'rol_rrhh';

GRANT SELECT ON control_acceso.personas  TO 'rol_auditor';
GRANT SELECT ON control_acceso.roles     TO 'rol_auditor';
GRANT SELECT ON control_acceso.accesos   TO 'rol_auditor';
GRANT SELECT ON control_acceso.auditoria TO 'rol_auditor';
GRANT SELECT (id_usuario, nombre_usuario, estado, id_persona, id_rol)
  ON control_acceso.usuarios TO 'rol_auditor';

GRANT SELECT, INSERT ON control_acceso.rostros  TO 'rol_servicio_biometrico';
GRANT SELECT, INSERT ON control_acceso.huellas  TO 'rol_servicio_biometrico';
GRANT SELECT ON control_acceso.personas         TO 'rol_servicio_biometrico';
GRANT INSERT ON control_acceso.accesos          TO 'rol_servicio_biometrico';

CREATE SQL SECURITY DEFINER VIEW control_acceso.v_mi_asistencia AS
SELECT a.fecha_hora, a.tipo, a.estado
FROM control_acceso.accesos a
JOIN control_acceso.usuarios u ON u.id_persona = a.id_persona
WHERE u.nombre_usuario = SUBSTRING_INDEX(USER(), '@', 1);

GRANT SELECT ON control_acceso.v_mi_asistencia TO 'rol_empleado';

CREATE USER 'svc_biometrico'@'10.0.0.%' IDENTIFIED BY 'cambiar_por_secreto_fuerte'
  REQUIRE SSL
  WITH MAX_USER_CONNECTIONS 50
  PASSWORD EXPIRE INTERVAL 90 DAY
  FAILED_LOGIN_ATTEMPTS 5 PASSWORD_LOCK_TIME 1;
GRANT 'rol_servicio_biometrico' TO 'svc_biometrico'@'10.0.0.%';
SET DEFAULT ROLE 'rol_servicio_biometrico' TO 'svc_biometrico'@'10.0.0.%';

CREATE USER 'u_rrhh_01'@'10.0.0.%' IDENTIFIED BY 'cambiar_por_secreto_fuerte'
  REQUIRE SSL PASSWORD EXPIRE INTERVAL 90 DAY FAILED_LOGIN_ATTEMPTS 5 PASSWORD_LOCK_TIME 1;
GRANT 'rol_rrhh' TO 'u_rrhh_01'@'10.0.0.%';
SET DEFAULT ROLE 'rol_rrhh' TO 'u_rrhh_01'@'10.0.0.%';

CREATE USER 'u_auditor_01'@'10.0.0.%' IDENTIFIED BY 'cambiar_por_secreto_fuerte'
  REQUIRE SSL PASSWORD EXPIRE INTERVAL 90 DAY FAILED_LOGIN_ATTEMPTS 5 PASSWORD_LOCK_TIME 1;
GRANT 'rol_auditor' TO 'u_auditor_01'@'10.0.0.%';
SET DEFAULT ROLE 'rol_auditor' TO 'u_auditor_01'@'10.0.0.%';

SHOW GRANTS FOR 'u_rrhh_01'@'10.0.0.%' USING 'rol_rrhh';
