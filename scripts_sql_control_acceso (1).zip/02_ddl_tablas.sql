CREATE TABLE areas (
  id_area     INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nombre_area VARCHAR(50) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE roles (
  id_rol      INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nombre_rol  VARCHAR(40) NOT NULL UNIQUE,
  descripcion VARCHAR(200)
) ENGINE=InnoDB;

CREATE TABLE personas (
  id_persona     INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nombre         VARCHAR(50) NOT NULL,
  apellido       VARCHAR(50) NOT NULL,
  documento      VARCHAR(20) NOT NULL UNIQUE,
  id_area        INT NOT NULL,
  estado         VARCHAR(10) NOT NULL DEFAULT 'ACTIVO',
  fecha_registro DATE NOT NULL DEFAULT (CURRENT_DATE),
  CONSTRAINT chk_per_estado CHECK (estado IN ('ACTIVO','INACTIVO')),
  FOREIGN KEY (id_area) REFERENCES areas (id_area)
) ENGINE=InnoDB;

CREATE TABLE usuarios (
  id_usuario     INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  nombre_usuario VARCHAR(50)  NOT NULL UNIQUE,
  password       VARCHAR(255) NOT NULL,
  estado         VARCHAR(10)  NOT NULL DEFAULT 'ACTIVO',
  id_persona     INT NOT NULL UNIQUE,
  id_rol         INT NOT NULL,
  FOREIGN KEY (id_persona) REFERENCES personas (id_persona),
  FOREIGN KEY (id_rol)     REFERENCES roles (id_rol)
) ENGINE=InnoDB;

CREATE TABLE rostros (
  id_rostro      INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_persona     INT NOT NULL,
  plantilla      VARBINARY(512) NOT NULL,
  iv             VARBINARY(16),
  fecha_registro DATE NOT NULL DEFAULT (CURRENT_DATE),
  FOREIGN KEY (id_persona) REFERENCES personas (id_persona) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE huellas (
  id_huella      INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  id_persona     INT NOT NULL,
  plantilla      VARBINARY(512) NOT NULL,
  iv             VARBINARY(16),
  fecha_registro DATE NOT NULL DEFAULT (CURRENT_DATE),
  FOREIGN KEY (id_persona) REFERENCES personas (id_persona) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE auditoria (
  id_auditoria BIGINT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  fecha_hora   DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  usuario_bd   VARCHAR(100) NOT NULL,
  tabla        VARCHAR(60)  NOT NULL,
  operacion    VARCHAR(10)  NOT NULL,
  id_afectado  INT,
  detalle      VARCHAR(255)
) ENGINE=InnoDB;
