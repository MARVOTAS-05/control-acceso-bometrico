# Manual de Instalación y Despliegue

Sistema de Control de Ingreso de Personal mediante Datos Biométricos
Base de datos: MySQL 8 (scripts verificados en MySQL 8.0.46)

## Requisitos previos

- Servidor con Linux (por ejemplo, Ubuntu Server 22.04 o superior), mínimo 4 núcleos, 8 GB de RAM y disco SSD con espacio para el crecimiento de los datos.
- Conectividad de red estable entre el servidor, los dispositivos biométricos y los equipos de Recursos Humanos.
- MySQL Workbench, DBeaver o el cliente `mysql` en el equipo del administrador.

## Pasos

1. **Instalar MySQL Server.** Los repositorios de Ubuntu traen MySQL 8.0; para la versión 8.4 LTS se usa el repositorio APT oficial de MySQL.

```bash
sudo apt update
sudo apt install -y mysql-server
```

2. **Asegurar la instalación:** elimina usuarios anónimos y la base de prueba, y fija la contraseña de `root`.

```bash
sudo mysql_secure_installation
```

3. **Configurar la seguridad** en `my.cnf` (sección `[mysqld]`) y reiniciar el servicio:

```ini
bind-address               = 10.0.0.5
require_secure_transport   = ON
tls_version                = TLSv1.2,TLSv1.3
skip_name_resolve          = ON
local_infile               = OFF
secure_file_priv           = /var/lib/mysql-files
max_connections            = 200
max_execution_time         = 30000
log_error_verbosity        = 3
log_bin                    = mysql-bin
binlog_expire_logs_seconds = 1209600
event_scheduler            = ON
```

```bash
sudo systemctl restart mysql
```

4. **Ejecutar los scripts en orden** desde esta carpeta:

```bash
mysql -u root -p < 01_esquema.sql
for f in 02_ddl_tablas.sql 03_particionamiento.sql 04_dml_datos.sql \
         05_triggers.sql 06_roles_rbac.sql; do
  mysql -u root -p control_acceso < "$f"
done
```

5. **Programar los respaldos** con `cron` y confirmar que el evento de particiones esté activo:

```sql
SHOW VARIABLES LIKE 'event_scheduler';
```

6. **Verificar la instalación** ejecutando `07_pruebas.sql` y comprobando que las pruebas de autorización den el resultado esperado.

7. **Conectar los dispositivos biométricos** y el servicio de autenticación con la cuenta `svc_biometrico`.

## Notas

- Las contraseñas de `06_roles_rbac.sql` son marcadores: cámbielas antes de usar.
- Las cuentas se crean para la red `10.0.0.%`; ajuste el host a la red real.
