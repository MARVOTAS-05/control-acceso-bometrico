CREATE DATABASE IF NOT EXISTS control_acceso
  CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci;
USE control_acceso;
