DELIMITER $$

CREATE TRIGGER trg_rostros_ai AFTER INSERT ON rostros
FOR EACH ROW
BEGIN
  INSERT INTO auditoria (usuario_bd, tabla, operacion, id_afectado, detalle)
  VALUES (CURRENT_USER(), 'rostros', 'INSERT', NEW.id_persona, 'Alta de plantilla facial');
END$$

CREATE TRIGGER trg_rostros_au AFTER UPDATE ON rostros
FOR EACH ROW
BEGIN
  INSERT INTO auditoria (usuario_bd, tabla, operacion, id_afectado, detalle)
  VALUES (CURRENT_USER(), 'rostros', 'UPDATE', NEW.id_persona, 'Modificación de plantilla facial');
END$$

CREATE TRIGGER trg_rostros_ad AFTER DELETE ON rostros
FOR EACH ROW
BEGIN
  INSERT INTO auditoria (usuario_bd, tabla, operacion, id_afectado, detalle)
  VALUES (CURRENT_USER(), 'rostros', 'DELETE', OLD.id_persona, 'Eliminación de plantilla facial');
END$$

CREATE TRIGGER trg_accesos_bi BEFORE INSERT ON accesos
FOR EACH ROW
BEGIN
  DECLARE v_ultimo VARCHAR(20);

  IF NEW.id_persona IS NOT NULL AND
     NOT EXISTS (SELECT 1 FROM personas WHERE id_persona = NEW.id_persona) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Persona inexistente';
  END IF;

  IF NEW.estado = 'EXITOSO' AND NEW.id_persona IS NOT NULL THEN
    SELECT tipo INTO v_ultimo
    FROM accesos
    WHERE id_persona = NEW.id_persona AND estado = 'EXITOSO'
      AND fecha_hora >= NEW.fecha_hora - INTERVAL 1 DAY
    ORDER BY fecha_hora DESC LIMIT 1;

    IF v_ultimo = NEW.tipo THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Acceso duplicado: mismo tipo consecutivo';
    END IF;
  END IF;
END$$

DELIMITER ;
