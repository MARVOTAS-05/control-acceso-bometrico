CREATE TABLE accesos (
  id_acceso  BIGINT NOT NULL AUTO_INCREMENT,
  id_persona INT NULL,
  tipo       VARCHAR(20) NOT NULL,
  estado     VARCHAR(20) NOT NULL,
  fecha_hora DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id_acceso, fecha_hora),
  KEY idx_accesos_persona_fecha (id_persona, fecha_hora),
  KEY idx_accesos_estado_fecha  (estado, fecha_hora),
  CONSTRAINT chk_acc_tipo   CHECK (tipo IN ('ENTRADA','SALIDA')),
  CONSTRAINT chk_acc_estado CHECK (estado IN ('EXITOSO','FALLIDO'))
) ENGINE=InnoDB
PARTITION BY RANGE COLUMNS (fecha_hora) (
  PARTITION p2026_04 VALUES LESS THAN ('2026-05-01'),
  PARTITION p2026_05 VALUES LESS THAN ('2026-06-01'),
  PARTITION p2026_06 VALUES LESS THAN ('2026-07-01'),
  PARTITION p_futuro VALUES LESS THAN (MAXVALUE)
);

DELIMITER $$

CREATE PROCEDURE sp_crear_particion_mensual(IN p_hasta DATE)
BEGIN
  DECLARE v_ult DATE;
  DECLARE v_fin DATE;

  -- Último límite de partición existente (sin contar p_futuro)
  SELECT MAX(STR_TO_DATE(REPLACE(PARTITION_DESCRIPTION, '''', ''), '%Y-%m-%d'))
    INTO v_ult
  FROM information_schema.PARTITIONS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'accesos'
    AND PARTITION_NAME <> 'p_futuro';

  -- Crea, mes a mes y sin dejar huecos, hasta cubrir el mes de p_hasta
  WHILE v_ult <= p_hasta DO
    SET v_fin = DATE_ADD(v_ult, INTERVAL 1 MONTH);
    SET @ddl = CONCAT(
      'ALTER TABLE accesos REORGANIZE PARTITION p_futuro INTO (',
      'PARTITION p', DATE_FORMAT(v_ult, '%Y_%m'), ' VALUES LESS THAN (''', v_fin, '''), ',
      'PARTITION p_futuro VALUES LESS THAN (MAXVALUE))');
    PREPARE stmt FROM @ddl;
    EXECUTE stmt;
    DEALLOCATE PREPARE stmt;
    SET v_ult = v_fin;
  END WHILE;
END$$

CREATE EVENT ev_particion_mensual
ON SCHEDULE EVERY 1 MONTH STARTS CURRENT_TIMESTAMP
DO CALL sp_crear_particion_mensual(DATE_ADD(CURDATE(), INTERVAL 1 MONTH))$$

DELIMITER ;
