USE control_acceso;

-- =====================================================================
-- 1) CARGA MASIVA (1 000 001 filas). Se elimina el trigger de validación
--    porque los datos sintéticos no respetan la alternancia entrada/salida.
-- =====================================================================
DROP TRIGGER IF EXISTS trg_accesos_bi;

SET SESSION cte_max_recursion_depth = 2000000;

INSERT INTO accesos (fecha_hora, id_persona, tipo, estado)
WITH RECURSIVE seq AS (
  SELECT 0 AS n UNION ALL SELECT n + 1 FROM seq WHERE n < 1000000
)
SELECT DATE_ADD('2026-04-01 00:00:00', INTERVAL n * 7 SECOND),
       1 + FLOOR(RAND() * 200),
       IF(RAND() < 0.5, 'ENTRADA', 'SALIDA'),
       IF(RAND() < 0.97, 'EXITOSO', 'FALLIDO')
FROM seq;

-- Se vuelve a crear el trigger de integridad y secuencia
DELIMITER $$
CREATE TRIGGER trg_accesos_bi BEFORE INSERT ON accesos
FOR EACH ROW
BEGIN
  DECLARE v_ultimo VARCHAR(20);

  IF NEW.id_persona IS NOT NULL AND
     NOT EXISTS (SELECT 1 FROM personas WHERE id_persona = NEW.id_persona) THEN
    SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Persona inexistente';
  END IF;

  IF NEW.estado = 'EXITOSO' AND NEW.id_persona IS NOT NULL THEN
    SELECT tipo INTO v_ultimo
    FROM accesos
    WHERE id_persona = NEW.id_persona AND estado = 'EXITOSO'
      AND fecha_hora >= NEW.fecha_hora - INTERVAL 1 DAY
    ORDER BY fecha_hora DESC LIMIT 1;

    IF v_ultimo = NEW.tipo THEN
      SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Acceso duplicado: mismo tipo consecutivo';
    END IF;
  END IF;
END$$
DELIMITER ;

-- =====================================================================
-- 2) VERIFICACIÓN DE LA PODA DE PARTICIONES
--    La columna "partitions" debe mostrar solo p2026_05
-- =====================================================================
EXPLAIN SELECT * FROM accesos
WHERE fecha_hora >= '2026-05-01' AND fecha_hora < '2026-06-01';

-- =====================================================================
-- 3) TABLA DE CONTROL SIN PARTICIONAR
-- =====================================================================
CREATE TABLE IF NOT EXISTS accesos_plana LIKE accesos;
ALTER TABLE accesos_plana REMOVE PARTITIONING;
INSERT INTO accesos_plana SELECT * FROM accesos;

-- =====================================================================
-- 4) CONSULTAS DE RENDIMIENTO (ejecutar cada una en accesos y en
--    accesos_plana, cambiando el nombre de la tabla, y anotar el tiempo)
-- =====================================================================
-- Q1: asistencia de una persona en un mes
EXPLAIN ANALYZE
SELECT * FROM accesos
WHERE id_persona = 45
  AND fecha_hora >= '2026-05-01' AND fecha_hora < '2026-06-01';

-- Q2: reporte diario de ingresos por área
EXPLAIN ANALYZE
SELECT ar.nombre_area, COUNT(*) AS ingresos
FROM accesos a
JOIN personas p ON p.id_persona = a.id_persona
JOIN areas ar   ON ar.id_area = p.id_area
WHERE a.fecha_hora >= '2026-05-15' AND a.fecha_hora < '2026-05-16'
  AND a.tipo = 'ENTRADA' AND a.estado = 'EXITOSO'
GROUP BY ar.nombre_area;

-- Q3: personas con más intentos fallidos del trimestre
EXPLAIN ANALYZE
SELECT id_persona, COUNT(*) AS fallidos FROM accesos
WHERE estado = 'FALLIDO' AND fecha_hora >= '2026-04-01'
GROUP BY id_persona ORDER BY fallidos DESC LIMIT 10;

-- =====================================================================
-- 5) ELIMINAR UN MES COMPLETO: DELETE frente a DROP PARTITION
--    (se mide el tiempo de cada uno; DROP PARTITION borra la partición)
-- =====================================================================
-- SET @t = NOW(6);
-- DELETE FROM accesos_plana WHERE fecha_hora < '2026-05-01';
-- SELECT ROUND(TIMESTAMPDIFF(MICROSECOND, @t, NOW(6)) / 1000) AS delete_ms;
--
-- SET @t = NOW(6);
-- ALTER TABLE accesos DROP PARTITION p2026_04;
-- SELECT ROUND(TIMESTAMPDIFF(MICROSECOND, @t, NOW(6)) / 1000) AS drop_partition_ms;

-- =====================================================================
-- 6) PRUEBAS DE AUTORIZACIÓN (ejecutar conectado con la cuenta indicada)
-- =====================================================================
-- u_rrhh_01    : SELECT * FROM control_acceso.rostros;
--                -> ERROR 1142 (denegado)
-- u_auditor_01 : SELECT password FROM control_acceso.usuarios;
--                -> ERROR 1143 (denegado por columna)
-- empleado     : SELECT COUNT(*) FROM control_acceso.v_mi_asistencia;
--                -> solo sus propias filas
-- empleado     : SELECT * FROM control_acceso.accesos LIMIT 1;
--                -> ERROR 1142 (denegado)
-- Nota: las cuentas del script 06 solo se conectan desde la red 10.0.0.%;
-- para probar en un solo equipo, cree cuentas equivalentes con @'localhost'.
